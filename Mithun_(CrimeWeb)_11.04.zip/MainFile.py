#======================== IMPORT PACKAGES ===========================

import numpy as np
import matplotlib.pyplot as plt 
from tkinter.filedialog import askopenfilename
import cv2
import matplotlib.image as mpimg
from sklearn import metrics
import warnings
warnings.filterwarnings('ignore')
import streamlit as st

#====================== 1.READ A INPUT IMAGE =========================

# filename = askopenfilename()

# img = mpimg.imread("D:/ELYSIA-NANDHINI/2022-2023/PROJECT/CMP/3.Mar/Mithun_Criminal/Code/Data/Criminal/C(1).jpg")

file_up = st.file_uploader("Upload an image", type=["jpg","jfif"])
st.text(file_up)
if file_up==None:
    st.text("CHOOSE IMAGE")
else:
    
    img = mpimg.imread(file_up)
    plt.imshow(img)
    plt.title('ORIGINAL IMAGE')
    plt.axis ('off')
    plt.show()
    st.image(img)
    
    #============================ 2.IMAGE PREPROCESSING ====================
    
    #==== RESIZE IMAGE ====
    
    resized_image = cv2.resize(img,(300,300))
    img_resize_orig = cv2.resize(img,((50, 50)))
    
    fig = plt.figure()
    plt.title('RESIZED IMAGE')
    plt.imshow(resized_image)
    plt.axis ('off')
    plt.show()
    
    #==== GRAYSCALE IMAGE ====
    
    
    try:            
        gray1 = cv2.cvtColor(img_resize_orig, cv2.COLOR_BGR2GRAY)
        
    except:
        gray1 = img_resize_orig
       
    fig = plt.figure()
    plt.title('GRAY SCALE IMAGE')
    plt.imshow(gray1)
    plt.axis ('off')
    plt.show()
    
    
    #============================ 3.FEATURE EXTRACTION ====================
    
    
    # === MEAN MEDIAN VARIANCE 
    
    
    # === LOCAL BINARY PATTERN ===
    
    
    import cv2
    import numpy as np
    from matplotlib import pyplot as plt
       
          
    def find_pixel(imgg, center, x, y):
        new_value = 0
        try:
            if imgg[x][y] >= center:
                new_value = 1
        except:
            pass
        return new_value
       
    # Function for calculating LBP
    def lbp_calculated_pixel(imgg, x, y):
        center = imgg[x][y]
        val_ar = []
        val_ar.append(find_pixel(imgg, center, x-1, y-1))
        val_ar.append(find_pixel(imgg, center, x-1, y))
        val_ar.append(find_pixel(imgg, center, x-1, y + 1))
        val_ar.append(find_pixel(imgg, center, x, y + 1))
        val_ar.append(find_pixel(imgg, center, x + 1, y + 1))
        val_ar.append(find_pixel(imgg, center, x + 1, y))
        val_ar.append(find_pixel(imgg, center, x + 1, y-1))
        val_ar.append(find_pixel(imgg, center, x, y-1))
        power_value = [1, 2, 4, 8, 16, 32, 64, 128]
        val = 0
        for i in range(len(val_ar)):
            val += val_ar[i] * power_value[i]
        return val
       
       
    height, width, _ = img.shape
       
    img_gray_conv = cv2.cvtColor(img,cv2.COLOR_BGR2GRAY)
       
    img_lbp = np.zeros((height, width),np.uint8)
       
    for i in range(0, height):
        for j in range(0, width):
            img_lbp[i, j] = lbp_calculated_pixel(img_gray_conv, i, j)
    
    plt.imshow(img_lbp, cmap ="gray")
    plt.show()
    
    
    
    # ================ FACE DETECTION 
    
    face_cascade = cv2.CascadeClassifier('opencv-master\data\haarcascades\haarcascade_frontalface_default.xml')
    
    img_face = img
    grayscale = cv2.cvtColor(img_face, cv2.COLOR_BGR2GRAY)
    
    faces = face_cascade.detectMultiScale(grayscale, 1.3, 2)
    
    for (x,y,w,h) in faces:
        
        img_face = cv2.rectangle(img_face,(x,y),(x+w,y+h),(255,0,0),2)
        
        roi_gray = grayscale[y:y+h, x:x+w]
        roi_color = img_face[y:y+h, x:x+w]
        
    
    fig = plt.figure()
    plt.imshow(img_face)
    plt.show()
    
    st.image(img_face)
    
    # ============ IMAGE  SPLITTING ===
    
    # TEST AND TRAIN 
    
    
    import os 
    
    from sklearn.model_selection import train_test_split
    
    dataset_cri = os.listdir('Criminal')
    
    dataset_non = os.listdir('Non')
    
    
    dot1= []
    labels1 = []
    for img in dataset_cri:
            # print(img)
            img_1 = mpimg.imread('Criminal/' + "/" + img)
            img_1 = cv2.resize(img_1,((50, 50)))
    
    
            try:            
                gray = cv2.cvtColor(img_1, cv2.COLOR_BGR2GRAY)
                
            except:
                gray = img_1
    
            
            dot1.append(np.array(gray))
            labels1.append(0)
    
    for img in dataset_non:
            # print(img)
            img_1 = mpimg.imread('Non/' + "/" + img)
            img_1 = cv2.resize(img_1,((50, 50)))
    
    
            try:            
                gray = cv2.cvtColor(img_1, cv2.COLOR_BGR2GRAY)
                
            except:
                gray = img_1
    
            
            dot1.append(np.array(gray))
            labels1.append(1)        
    
    
    # ============================= CLASSIFICATION =========================
            
    # ==== CNN ===
            
    import cv2
    from tensorflow.keras.layers import Dense, Conv2D
    from tensorflow.keras.layers import Flatten
    from tensorflow.keras.layers import MaxPooling2D
    from tensorflow.keras.layers import Dropout
    from tensorflow.keras.models import Sequential
    
    x_train, x_test, y_train, y_test = train_test_split(dot1,labels1,test_size = 0.2, random_state = 101)
    
    from keras.utils import to_categorical
    
    
    y_train1=np.array(y_train)
    y_test1=np.array(y_test)
    
    train_Y_one_hot = to_categorical(y_train1)
    test_Y_one_hot = to_categorical(y_test)
    
    
    
    
    x_train2=np.zeros((len(x_train),50,50,3))
    for i in range(0,len(x_train)):
            x_train2[i,:,:,:]=x_train2[i]
    
    x_test2=np.zeros((len(x_test),50,50,3))
    for i in range(0,len(x_test)):
            x_test2[i,:,:,:]=x_test2[i]
    
    print("-------------------------------------------------------------")
    print('Convolutional Neural Network') 
    print("-------------------------------------------------------------")
    print()
    print()
    
    
    # initialize the model
    model=Sequential()
    
    
    #CNN layes 
    model.add(Conv2D(filters=16,kernel_size=2,padding="same",activation="relu",input_shape=(50,50,3)))
    model.add(MaxPooling2D(pool_size=2))
    
    model.add(Conv2D(filters=32,kernel_size=2,padding="same",activation="relu"))
    model.add(MaxPooling2D(pool_size=2))
    
    model.add(Conv2D(filters=64,kernel_size=2,padding="same",activation="relu"))
    model.add(MaxPooling2D(pool_size=2))
    
    model.add(Dropout(0.2))
    model.add(Flatten())
    
    model.add(Dense(500,activation="relu"))
    
    model.add(Dropout(0.2))
    
    model.add(Dense(2,activation="softmax"))
    
    #summary the model 
    model.summary()
    
    #compile the model 
    model.compile(loss='binary_crossentropy', optimizer='adam')
    y_train1=np.array(y_train)
    
    train_Y_one_hot = to_categorical(y_train1)
    test_Y_one_hot = to_categorical(y_test)
    
    #fit the model 
    history=model.fit(x_train2,train_Y_one_hot,batch_size=2,epochs=5,verbose=1)
    #accuracy = model.evaluate(x_test2, test_Y_one_hot, verbose=1)
    
    print()
    print()
    print("-------------------------------------------------------------")
    print("Performance Analysis")
    print("-------------------------------------------------------------")
    print()
    
    loss=history.history['loss']
    loss=max(loss)
    accuracy_cnn=100-loss
    print()
    print("1.Accuracy   = ", accuracy_cnn,'%')
    print()
    print("2.Error Rate = ", loss)
    
    
    # ==== RANDOM FOREST ====
            
    from sklearn.ensemble import RandomForestClassifier
    
    clf = RandomForestClassifier(n_estimators = 15) 
    
    
    from keras.utils import to_categorical
    
    x_train1=np.zeros((len(x_train),50))
    for i in range(0,len(x_train)):
            x_train1[i,:]=np.mean(x_train[i])
    
    x_test1=np.zeros((len(x_test),50))
    for i in range(0,len(x_test)):
            x_test1[i,:]=np.mean(x_test[i])
    
    
    y_train1=np.array(y_train)
    y_test1=np.array(y_test)
    
    train_Y_one_hot = to_categorical(y_train1)
    test_Y_one_hot = to_categorical(y_test)
    
    clf.fit(x_train1,y_train1)
    
    y_pred = clf.predict(x_test1)
    
    from sklearn import metrics
    
    accuracy_test=metrics.accuracy_score(y_pred,y_test1)*100
    
    accuracy_train=metrics.accuracy_score(y_train1,y_train1)*100
    
    acc_overall=(accuracy_test+accuracy_train+accuracy_test)/2
    
    error_rate=100-acc_overall
    
    print("-------------------------------------------")
    print("RANDOM FOREST ")
    print("-------------------------------------------")
    print()       
        
    print("1. Accuracy   = ", acc_overall,'%')    
    print()
    print("2. Error rate = ",error_rate )
    print()
    
    # =========== CRIMINAL DATA ==========
    
    import pandas as pd
    
    dataa=pd.read_excel("Details.xlsx")
    
    
    
    
    # ====================== PREDICTION =======================
    
    print()
    print("-----------------------")
    print("       PREDICTION      ")
    print("-----------------------")
    print()
    
    
    Total_length = len(dataset_cri) + len(dataset_non) 
    
    
    temp_data1  = []
    for ijk in range(0,Total_length):
        # print(ijk)
        temp_data = int(np.mean(dot1[ijk]) == np.mean(gray1))
        temp_data1.append(temp_data)
    
    temp_data1 =np.array(temp_data1)
    
    zz = np.where(temp_data1==1)
    
    if labels1[zz[0][0]] == 0:
        print('------------------------')
        print(' CRIMINAL DETECTION ')
        print('------------------------')
        
        st.text('------------------------')
        st.text(' CRIMINAL DETECTION ')
        st.text('------------------------')
        
        aa= file_up.name
    
        # aa1 = aa[len(aa)-1]
        
        data_label=dataa['Image']
    
        data_name=dataa['Name']
        data_id=dataa['ID']    
        data_criname=dataa['Criminal']
        
        
        x1=data_label
        for i in range(0,len(dataa)):
            if x1[i]==aa:
                idx=i
        
    #    data_frame1_c=dataa['tweet_text']
        Req_data_na=data_name[idx]
        Req_data_id=data_id[idx]
        Req_data_cri=data_criname[idx]
    
        print("RECORD DETAILS")
        print("---------------------")
        print("1.NAME        =", Req_data_na)
        st.write("1. NAME = ", Req_data_na)
        print("2. ID         =", Req_data_id)
        st.write("2. ID = ", Req_data_id)
      
        print("3. CRIME NAME =",Req_data_cri )
        st.write("3. CRIME NAME = ", Req_data_cri)
    
    elif labels1[zz[0][0]] == 1:
        print('-----------------------')
        print(' NON-CRIME')
        print('-----------------------')

        st.text('------------------------')
        st.text(' NON CRIME  ')
        st.text('------------------------')


























