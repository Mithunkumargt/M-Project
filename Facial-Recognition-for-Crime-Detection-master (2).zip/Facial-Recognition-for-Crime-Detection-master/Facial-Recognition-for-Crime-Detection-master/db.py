import pymysql

# Open database connection
db = pymysql.connect(
    host="localhost",  # your host name
    user="root",  # your username
    password="shantha",  # your root password
    database="shanthadb"  # your database name
)

# Create a cursor object
cursor = db.cursor()

# Execute SQL query
cursor.execute("SELECT VERSION()")

# Fetch a single row using fetchone() method
data = cursor.fetchone()

# Print the database version
print("Database version : %s " % data)

# Close the cursor and database connection
cursor.close()
db.close()
